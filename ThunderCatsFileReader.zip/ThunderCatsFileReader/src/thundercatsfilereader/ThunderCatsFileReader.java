/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thundercatsfilereader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


/**
 *
 * @author maroselli
 */
public class ThunderCatsFileReader {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     * @throws java.text.ParseException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
        String name;
        Date date;
        String time;
        int length;
        String fellow;
        String draftname;
        //when incorporated with other code this should loop for multiple files
        ArrayList<String> lines;
        lines = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("D://Example17.txt")); //or ask user via Scanner
        String line = br.readLine();
        //separates each line in file and creates an array
        while (line != null)
        {
            lines.add(line);
            line = br.readLine();
        } 
        //these commands store the parts of the file into categories 
        //later we could put these back into an appointment object if favorable
        name = lines.get(0); //arraylist at each integer
        String datestring = lines.get(1);
        //for date class you need to set a format
        SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss"); 
        date = dateformat.parse(datestring);  //sets date
        //time as string right?
        time = lines.get(2);
        String lengthstring = lines.get(3); //length should be an integer in minutes
        length = Integer.parseInt(lengthstring);
        fellow = lines.get(4);
        draftname = lines.get(5);
    }
    
}
