/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thundercatsfilereader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author maroselli
 */
public class FileReaderClass {
public ArrayList filereader(String filename) throws FileNotFoundException, IOException, ParseException
{
        String name;
        String date;
        String time;
        String length;
        String fellow;
        String draftname;
        //when incorporated with other code this should loop for multiple files
        ArrayList<String> lines;
        lines = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader("D://Example17.txt")); //or ask user via Scanner
        String line = br.readLine();
        //separates each line in file and creates an array
        while (line != null)
        {
            lines.add(line);
            line = br.readLine();
        } 
        ArrayList <Appointment> apptlist = new ArrayList<>;
        int a=0;
        int b=1; 
        int c=2; 
        int d=4;
        int e=4; 
        int f=5;
        for(int i = 0; i<lines.size()/5;i++)
        {
        //these commands store the parts of the file into categories 
        //later we could put these back into an appointment object if favorable
        name = lines.get(a); //arraylist at each integer
        date = lines.get(b);  //sets date
        time = lines.get(c);
        length = lines.get(d);
        fellow = lines.get(e);
        draftname = lines.get(f);   
        a+=5;
        b+=5;
        c+=5;
        d+=5;
        e+=5;
        f+=5;
         
        //now put into Appointment object
        Appointment appt = Appointment(name, date, time, length, fellow, draftname); 
        apptlist.add(appt);
        }
        return apptlist;
        }
}
